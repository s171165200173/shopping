package com.istore.model;

public class Login
{
String name;
String pwd;

public Login()
{

}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getPwd() {
	return pwd;
}
public void setPwd(String pwd) {
	this.pwd = pwd;
}

}
