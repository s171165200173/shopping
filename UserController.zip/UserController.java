package com.istore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.istore.dao.UserDAO;
import com.istore.model.User;

@Controller
public class UserController {

	@Autowired
	UserDAO userdao;

	@RequestMapping(value="register", method=RequestMethod.GET)
	public ModelAndView sendregister (@ModelAttribute("user")User user)
	{
		ModelAndView mv=new ModelAndView("register");
		return mv;
	}
	@RequestMapping(value="register", method=RequestMethod.GET)
	public ModelAndView getUser (User user)
	{

		userdao.addUser(user);
		ModelAndView mv=new ModelAndView("login","user",new User());
		return mv;
	}
	
	
		
	
}

