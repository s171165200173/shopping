package com.istore.dao;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.istore.model.Cart;
import com.istore.model.Product;
import com.google.gson.Gson;



@Repository
public class CartDAO
{
	
	
}
